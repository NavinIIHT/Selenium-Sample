package com.iiht.evaluation.automation;

import java.util.HashMap;
import java.util.Map;

public class locators {
    public static final Map<String, String> arrival_images_add_to_basket_element = new HashMap<>();

    static {
        arrival_images_add_to_basket_element.put("shop_menu_link", "//li[contains(@id,'menu-item')]/a[text()='Shop']");
        arrival_images_add_to_basket_element.put("shop_page_nav", "//div[@id='content']/nav");
        arrival_images_add_to_basket_element.put("home_menu_link", "//div[@id='content']/nav/a[text()='Home']");
        arrival_images_add_to_basket_element.put("new_arrival_div", "//h2[text()='new arrivals']/ancestor::div[contains(@class,'first tb-column')]");
        arrival_images_add_to_basket_element.put("new_arrival_product_ul_list", "//h2[text()='new arrivals']/ancestor::div[contains(@class,'first tb-column')]/descendant::ul[@class='products']");
        arrival_images_add_to_basket_element.put("new_arrival_product_h3_text", "//h2[text()='new arrivals']/ancestor::div[contains(@class,'first tb-column')]/descendant::ul[@class='products']/descendant::h3[text()='$(product_name)']");
        arrival_images_add_to_basket_element.put("new_arrival_product_h3_text_link", "//h2[text()='new arrivals']/ancestor::div[contains(@class,'first tb-column')]/descendant::ul[@class='products']/descendant::h3[text()='$(product_name)']/parent::a");
        arrival_images_add_to_basket_element.put("new_arrival_product_page_nav", "//div[@id='content']/nav");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_name_text", "//div[contains(@class,'summary')]/h1[text()='$(product_name)']");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_price_text", "//div[contains(@class,'summary')]/h1[text()='$(product_name)']/following-sibling::div/p[contains(.,'$(price_text)')]");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_add_to_basket_button", "//button[text()='Add to basket']");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_add_to_basket_message", "//div[@id='content']/descendant::div[contains(@class,'message')]");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_item_count_number", "//form[@class='cart']/descendant::input[@type='number']");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_cart_item_detail_li", "//li[@id='wpmenucartli']/a");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_cart_item_detail_no_of_item_span", "//li[@id='wpmenucartli']/a/descendant::span[1]");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_content_container", "//div[@class='pp_content_container']");
        arrival_images_add_to_basket_element.put("new_arrival_product_summary_content_container_close_link", "//div[@class='pp_content_container']/descendant::a[contains(.,'Close')]");

    }
}
